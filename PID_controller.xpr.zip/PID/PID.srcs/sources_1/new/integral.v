// integral.v
// I term of PID: accumulates Ki * error_in each sample_en pulse.
// Anti-windup: the accumulator itself is clamped (via the saturate module)
// to ACC_WIDTH -> ACC_WIDTH range each cycle, so it can never grow past the
// clamp bound no matter how long the error stays saturated. This is what
// prevents integrator windup (accumulator running away while output is
// already maxed, causing large overshoot when error finally reverses).
//
// Ki is fixed-point, same Q-format convention as Kp (default Q4.12).

`timescale 1ns/1ps

module integral #(
    parameter DATA_WIDTH  = 16,
    parameter COEFF_WIDTH = 16,
    parameter FRAC_BITS   = 12,
    parameter ACC_WIDTH   = 32
) (
    input  wire                          clk,
    input  wire                          rst_n,
    input  wire                          sample_en,
    input  wire signed [DATA_WIDTH-1:0]  error_in,
    input  wire signed [COEFF_WIDTH-1:0] ki,
    input  wire signed [ACC_WIDTH-1:0]   windup_limit_pos,
    input  wire signed [ACC_WIDTH-1:0]   windup_limit_neg,
    output wire signed [ACC_WIDTH-1:0]   i_out,
    output wire                          windup_flag
);

    wire signed [DATA_WIDTH+COEFF_WIDTH-1:0] ki_error_product;
    assign ki_error_product = error_in * ki;

    wire signed [ACC_WIDTH-1:0] increment;
    assign increment = ki_error_product >>> FRAC_BITS;

    wire signed [ACC_WIDTH:0] acc_next_wide;
    reg  signed [ACC_WIDTH-1:0] acc_reg;
    assign acc_next_wide = {acc_reg[ACC_WIDTH-1], acc_reg} + {increment[ACC_WIDTH-1], increment};

    wire signed [ACC_WIDTH-1:0] acc_sat;
    wire                        acc_sat_flag;

    saturate #(
        .IN_WIDTH  (ACC_WIDTH+1),
        .OUT_WIDTH (ACC_WIDTH)
    ) acc_saturate (
        .in_val   (acc_next_wide),
        .out_val  (acc_sat),
        .sat_flag (acc_sat_flag)
    );

    wire signed [ACC_WIDTH-1:0] acc_clamped;
    wire limit_hit_pos = (acc_sat > windup_limit_pos);
    wire limit_hit_neg = (acc_sat < windup_limit_neg);
    assign acc_clamped = limit_hit_pos ? windup_limit_pos :
                          limit_hit_neg ? windup_limit_neg :
                          acc_sat;

    // windup_flag is registered in lockstep with acc_reg so it always
    // describes the SAME sample as i_out. If left combinational, it would
    // recompute off the just-updated acc_reg on the next delta-cycle and
    // effectively preview one sample ahead of i_out.
    reg windup_flag_reg;

    assign i_out       = acc_reg;
    assign windup_flag = windup_flag_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            acc_reg         <= {ACC_WIDTH{1'b0}};
            windup_flag_reg <= 1'b0;
        end else if (sample_en) begin
            acc_reg         <= acc_clamped;
            windup_flag_reg <= acc_sat_flag | limit_hit_pos | limit_hit_neg;
        end
    end

endmodule

