// tb_proportional.v
// Self-checking testbench for proportional.v
// Kp in Q4.12: 1.0 -> 4096, 0.5 -> 2048, -2.0 -> -8192, 1.5 -> 6144

`timescale 1ns/1ps

module tb_proportional;

    localparam DATA_WIDTH  = 16;
    localparam COEFF_WIDTH = 16;
    localparam FRAC_BITS   = 12;
    localparam OUT_WIDTH   = 32;
    localparam CLK_PERIOD  = 10;

    reg                          clk = 0;
    reg                          rst_n;
    reg                          sample_en;
    reg  signed [DATA_WIDTH-1:0]  error_in;
    reg  signed [COEFF_WIDTH-1:0] kp;
    wire signed [OUT_WIDTH-1:0]   p_out;

    integer errors = 0;
    integer tests  = 0;

    proportional #(
        .DATA_WIDTH  (DATA_WIDTH),
        .COEFF_WIDTH (COEFF_WIDTH),
        .FRAC_BITS   (FRAC_BITS),
        .OUT_WIDTH   (OUT_WIDTH)
    ) dut (
        .clk       (clk),
        .rst_n     (rst_n),
        .sample_en (sample_en),
        .error_in  (error_in),
        .kp        (kp),
        .p_out     (p_out)
    );

    always #(CLK_PERIOD/2) clk = ~clk;

    task apply_and_check(
        input signed [DATA_WIDTH-1:0]  t_error,
        input signed [COEFF_WIDTH-1:0] t_kp,
        input signed [OUT_WIDTH-1:0]   exp_out,
        input [127:0]                  name
    );
    begin
        error_in  = t_error;
        kp        = t_kp;
        sample_en = 1'b1;
        @(posedge clk);
        #1;
        sample_en = 1'b0;

        tests = tests + 1;
        if (p_out !== exp_out) begin
            errors = errors + 1;
            $display("FAIL [%0s]: error=%0d kp=%0d -> p_out=%0d (exp %0d)",
                       name, t_error, t_kp, p_out, exp_out);
        end else begin
            $display("PASS [%0s]: error=%0d kp=%0d -> p_out=%0d", name, t_error, t_kp, p_out);
        end
    end
    endtask

    initial begin
        $display("---- tb_proportional start ----");

        rst_n     = 0;
        sample_en = 0;
        error_in  = 0;
        kp        = 0;
        repeat (2) @(posedge clk);
        #1;
        tests = tests + 1;
        if (p_out !== 0) begin
            errors = errors + 1;
            $display("FAIL [reset]: p_out=%0d (exp 0)", p_out);
        end else begin
            $display("PASS [reset]: p_out=0");
        end
        rst_n = 1;
        @(posedge clk); #1;

        apply_and_check(16'sd100, 16'sd4096, 32'sd100, "kp_1p0_pos");
        apply_and_check(16'sd100, 16'sd2048, 32'sd50, "kp_0p5");
        apply_and_check(16'sd50, -16'sd8192, -32'sd100, "kp_neg2p0");
        apply_and_check(-16'sd40, 16'sd6144, -32'sd60, "kp_1p5_neg_error");
        apply_and_check(16'sd0, 16'sd6144, 32'sd0, "zero_error");

        error_in = 16'sd9999;
        kp       = 16'sd4096;
        sample_en = 1'b0;
        @(posedge clk); #1;
        tests = tests + 1;
        if (p_out !== 32'sd0) begin
            errors = errors + 1;
            $display("FAIL [hold_no_en]: p_out=%0d (exp 0, held)", p_out);
        end else begin
            $display("PASS [hold_no_en]: p_out held at 0");
        end

        $display("---- tb_proportional done: %0d/%0d passed ----", tests-errors, tests);
        if (errors == 0) $display("*** ALL TESTS PASSED ***");
        else $display("*** %0d TEST(S) FAILED ***", errors);

        $finish;
    end

endmodule