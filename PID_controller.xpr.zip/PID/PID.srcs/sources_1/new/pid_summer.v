// pid_summer.v
// Combines P + I + D terms into the final PID output.
// Adds 2 guard bits before summing (3 terms -> worst-case growth needs
// ceil(log2(3)) = 2 extra bits) so the addition itself can never wrap around,
// then clamps down to OUT_WIDTH (14-bit, matching Red Pitaya's native DAC
// width) via the shared, already-verified saturate module.
//
// Deliberately COMBINATIONAL (no clk/sample_en) -- p_in/i_in/d_in are already
// registered, held-stable outputs from proportional/integral/derivative, so
// this just continuously reflects their current sum. Registering pid_out on
// the same sample_en edge that updates P/I/D would capture last sample's sum
// instead of the current one (non-blocking assignments all read pre-edge
// values simultaneously), adding a full extra sample period of pure delay to
// the loop -- a real stability/phase-margin problem, not just a cosmetic lag.

`timescale 1ns/1ps

module pid_summer #(
    parameter IN_WIDTH  = 32,  // width of each of p_in/i_in/d_in
    parameter OUT_WIDTH = 14   // final DAC-facing output width
) (
    input  wire signed [IN_WIDTH-1:0]    p_in,
    input  wire signed [IN_WIDTH-1:0]    i_in,
    input  wire signed [IN_WIDTH-1:0]    d_in,
    output wire signed [OUT_WIDTH-1:0]   pid_out,
    output wire                          sat_flag   // 1 = final output was clamped
);

    localparam SUM_WIDTH = IN_WIDTH + 2;

    // Sign-extend each term by 2 guard bits before adding, so the sum itself
    // cannot overflow/wrap regardless of how large p/i/d individually are.
    wire signed [SUM_WIDTH-1:0] p_ext = {{2{p_in[IN_WIDTH-1]}}, p_in};
    wire signed [SUM_WIDTH-1:0] i_ext = {{2{i_in[IN_WIDTH-1]}}, i_in};
    wire signed [SUM_WIDTH-1:0] d_ext = {{2{d_in[IN_WIDTH-1]}}, d_in};

    wire signed [SUM_WIDTH-1:0] sum;
    assign sum = p_ext + i_ext + d_ext;

    saturate #(
        .IN_WIDTH  (SUM_WIDTH),
        .OUT_WIDTH (OUT_WIDTH)
    ) out_sat (
        .in_val   (sum),
        .out_val  (pid_out),
        .sat_flag (sat_flag)
    );

endmodule