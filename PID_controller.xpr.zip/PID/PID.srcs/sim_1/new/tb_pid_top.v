// tb_pid_step_response.v
// Closed-loop demo: pid_top drives a simple simulated "plant" (first-order
// lag toward pid_out) toward a fixed setpoint. error_in is continuously
// recomputed as setpoint - plant_output, closing the loop. This is NOT a
// formal correctness test (that's tb_pid_top.v) -- it's for visualizing
// the classic rise / overshoot / settle step response shape.

`timescale 1ns/1ps

module tb_pid_step_response;

    localparam DATA_WIDTH  = 16;
    localparam COEFF_WIDTH = 16;
    localparam FRAC_BITS   = 12;
    localparam TERM_WIDTH  = 32;
    localparam OUT_WIDTH   = 14;
    localparam DIVIDE      = 2;
    localparam CLK_PERIOD  = 10;

    localparam signed [DATA_WIDTH-1:0] SETPOINT   = 16'sd3000;
    localparam LAG_SHIFT = 3; // plant moves 1/8 of the remaining gap toward pid_out each sample

    reg                          clk = 0;
    reg                          rst_n;
    reg  signed [COEFF_WIDTH-1:0] kp, ki, kd;
    reg  signed [TERM_WIDTH-1:0]  windup_limit_pos, windup_limit_neg;
    wire signed [OUT_WIDTH-1:0]   pid_out;
    wire                          out_sat_flag;
    wire                          windup_flag;
    wire                          sample_en;

    reg signed [DATA_WIDTH-1:0] plant_output;
    wire signed [DATA_WIDTH-1:0] error_in;
    assign error_in = SETPOINT - plant_output;

    integer sample_num = 0;

    pid_top #(
        .DATA_WIDTH  (DATA_WIDTH),
        .COEFF_WIDTH (COEFF_WIDTH),
        .FRAC_BITS   (FRAC_BITS),
        .TERM_WIDTH  (TERM_WIDTH),
        .OUT_WIDTH   (OUT_WIDTH),
        .DIVIDE      (DIVIDE)
    ) dut (
        .clk              (clk),
        .rst_n            (rst_n),
        .error_in         (error_in),
        .kp               (kp),
        .ki               (ki),
        .kd               (kd),
        .windup_limit_pos (windup_limit_pos),
        .windup_limit_neg (windup_limit_neg),
        .pid_out          (pid_out),
        .out_sat_flag     (out_sat_flag),
        .windup_flag      (windup_flag),
        .sample_en        (sample_en)
    );

    always #(CLK_PERIOD/2) clk = ~clk;

    always @(posedge clk) begin
        if (sample_en && rst_n) begin
            plant_output <= plant_output + ((pid_out - plant_output) >>> LAG_SHIFT);
            sample_num    = sample_num + 1;
            $display("CSV,%0d,%0d,%0d,%0d", sample_num, error_in, pid_out, plant_output);
        end
    end

    initial begin
        rst_n            = 0;
        plant_output     = 0;
        kp               = 16'sd6144;  // 1.5
        ki               = 16'sd1024;  // 0.25
        kd               = 16'sd2048;  // 0.5
        windup_limit_pos = 32'sd500000;
        windup_limit_neg = -32'sd500000;
        repeat (3) @(posedge clk);
        rst_n = 1;

        repeat (150) @(posedge sample_en);

        $display("DONE");
        $finish;
    end

endmodule