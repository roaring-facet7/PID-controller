// pid_top.v
`timescale 1ns/1ps

module pid_top #(
    parameter DATA_WIDTH  = 16,
    parameter COEFF_WIDTH = 16,
    parameter FRAC_BITS   = 12,
    parameter TERM_WIDTH  = 32,
    parameter OUT_WIDTH   = 14,
    parameter DIVIDE      = 1000
) (
    input  wire                          clk,
    input  wire                          rst_n,
    input  wire signed [DATA_WIDTH-1:0]  error_in,
    input  wire signed [COEFF_WIDTH-1:0] kp,
    input  wire signed [COEFF_WIDTH-1:0] ki,
    input  wire signed [COEFF_WIDTH-1:0] kd,
    input  wire signed [TERM_WIDTH-1:0]  windup_limit_pos,
    input  wire signed [TERM_WIDTH-1:0]  windup_limit_neg,
    output wire signed [OUT_WIDTH-1:0]   pid_out,
    output wire                          out_sat_flag,
    output wire                          windup_flag,
    output wire                          sample_en
);
    wire signed [TERM_WIDTH-1:0] p_out, i_out, d_out;

    sample_en_gen #(.DIVIDE(DIVIDE)) sen_gen (
        .clk(clk), .rst_n(rst_n), .sample_en(sample_en)
    );

    proportional #(.DATA_WIDTH(DATA_WIDTH), .COEFF_WIDTH(COEFF_WIDTH),
                   .FRAC_BITS(FRAC_BITS), .OUT_WIDTH(TERM_WIDTH)) p_block (
        .clk(clk), .rst_n(rst_n), .sample_en(sample_en),
        .error_in(error_in), .kp(kp), .p_out(p_out)
    );

    integral #(.DATA_WIDTH(DATA_WIDTH), .COEFF_WIDTH(COEFF_WIDTH),
               .FRAC_BITS(FRAC_BITS), .ACC_WIDTH(TERM_WIDTH)) i_block (
        .clk(clk), .rst_n(rst_n), .sample_en(sample_en),
        .error_in(error_in), .ki(ki),
        .windup_limit_pos(windup_limit_pos), .windup_limit_neg(windup_limit_neg),
        .i_out(i_out), .windup_flag(windup_flag)
    );

    derivative #(.DATA_WIDTH(DATA_WIDTH), .COEFF_WIDTH(COEFF_WIDTH),
                 .FRAC_BITS(FRAC_BITS), .OUT_WIDTH(TERM_WIDTH)) d_block (
        .clk(clk), .rst_n(rst_n), .sample_en(sample_en),
        .error_in(error_in), .kd(kd), .d_out(d_out)
    );

    pid_summer #(.IN_WIDTH(TERM_WIDTH), .OUT_WIDTH(OUT_WIDTH)) summer (
        .p_in(p_out), .i_in(i_out), .d_in(d_out),
        .pid_out(pid_out), .sat_flag(out_sat_flag)
    );
endmodule
