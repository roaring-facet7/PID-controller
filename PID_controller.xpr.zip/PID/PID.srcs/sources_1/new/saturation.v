// saturate.v
// Combinational signed saturation: clamps IN_WIDTH-bit signed input down to
// OUT_WIDTH-bit signed output. Used standalone at the PID output stage, and
// reused inside the integrator for anti-windup clamping.

`timescale 1ns/1ps

module saturate #(
    parameter IN_WIDTH  = 32,
    parameter OUT_WIDTH = 16
) (
    input  wire signed [IN_WIDTH-1:0]  in_val,
    output reg  signed [OUT_WIDTH-1:0] out_val,
    output reg                         sat_flag
);

    localparam signed [IN_WIDTH-1:0] MAX_OUT = (1 <<< (OUT_WIDTH-1)) - 1;
    localparam signed [IN_WIDTH-1:0] MIN_OUT = -(1 <<< (OUT_WIDTH-1));

    always @(*) begin
        if (in_val > MAX_OUT) begin
            out_val  = MAX_OUT[OUT_WIDTH-1:0];
            sat_flag = 1'b1;
        end else if (in_val < MIN_OUT) begin
            out_val  = MIN_OUT[OUT_WIDTH-1:0];
            sat_flag = 1'b1;
        end else begin
            out_val  = in_val[OUT_WIDTH-1:0];
            sat_flag = 1'b0;
        end
    end

endmodule