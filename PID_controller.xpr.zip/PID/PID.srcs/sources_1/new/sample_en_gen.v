// sample_en_gen.v
// Generates a single-cycle sample_en pulse every DIVIDE clk cycles.
`timescale 1ns/1ps

module sample_en_gen #(
    parameter DIVIDE = 1000
) (
    input  wire clk,
    input  wire rst_n,
    output reg  sample_en
);
    localparam CNT_WIDTH = $clog2(DIVIDE);
    reg [CNT_WIDTH-1:0] count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            count     <= {CNT_WIDTH{1'b0}};
            sample_en <= 1'b0;
        end else if (count == DIVIDE - 1) begin
            count     <= {CNT_WIDTH{1'b0}};
            sample_en <= 1'b1;
        end else begin
            count     <= count + 1'b1;
            sample_en <= 1'b0;
        end
    end
endmodule