// proportional.v
// P term of PID: p_out = error_in * Kp, registered on sample_en.
// Kp is fixed-point, Q(COEFF_WIDTH-FRAC_BITS).FRAC_BITS format (default Q4.12).
// OUT_WIDTH is kept wide (default 32) to avoid overflow before the summer;
// final clamp to DAC range happens later via the saturate module.

`timescale 1ns/1ps

module proportional #(
    parameter DATA_WIDTH  = 16,
    parameter COEFF_WIDTH = 16,
    parameter FRAC_BITS   = 12,
    parameter OUT_WIDTH   = 32
) (
    input  wire                          clk,
    input  wire                          rst_n,
    input  wire                          sample_en,
    input  wire signed [DATA_WIDTH-1:0]  error_in,
    input  wire signed [COEFF_WIDTH-1:0] kp,
    output reg  signed [OUT_WIDTH-1:0]   p_out
);

    wire signed [DATA_WIDTH+COEFF_WIDTH-1:0] product;
    assign product = error_in * kp;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p_out <= {OUT_WIDTH{1'b0}};
        end else if (sample_en) begin
            p_out <= product >>> FRAC_BITS;
        end
    end

endmodule