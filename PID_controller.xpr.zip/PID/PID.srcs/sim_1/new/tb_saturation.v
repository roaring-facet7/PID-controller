// tb_saturate.v
// Self-checking testbench for saturate.v
// Uses small widths (IN=12, OUT=8) so expected values are easy to hand-verify.

`timescale 1ns/1ps

module tb_saturate;

    localparam IN_WIDTH  = 12;
    localparam OUT_WIDTH = 8;

    reg  signed [IN_WIDTH-1:0]  in_val;
    wire signed [OUT_WIDTH-1:0] out_val;
    wire                        sat_flag;

    integer errors = 0;
    integer tests  = 0;

    saturate #(
        .IN_WIDTH  (IN_WIDTH),
        .OUT_WIDTH (OUT_WIDTH)
    ) dut (
        .in_val   (in_val),
        .out_val  (out_val),
        .sat_flag (sat_flag)
    );

    task check(
        input signed [IN_WIDTH-1:0]  test_in,
        input signed [OUT_WIDTH-1:0] exp_out,
        input                        exp_flag,
        input [127:0]                name
    );
    begin
        in_val = test_in;
        #1;
        tests = tests + 1;
        if (out_val !== exp_out || sat_flag !== exp_flag) begin
            errors = errors + 1;
            $display("FAIL [%0s]: in=%0d  out=%0d (exp %0d)  flag=%0b (exp %0b)",
                       name, test_in, out_val, exp_out, sat_flag, exp_flag);
        end else begin
            $display("PASS [%0s]: in=%0d  out=%0d  flag=%0b", name, test_in, out_val, sat_flag);
        end
    end
    endtask

    initial begin
        $display("---- tb_saturate start ----");
        check(12'sd50,    8'sd50,   1'b0, "mid_pos");
        check(-12'sd50,   -8'sd50,  1'b0, "mid_neg");
        check(12'sd127,   8'sd127,  1'b0, "pos_boundary_exact");
        check(12'sd128,   8'sd127,  1'b1, "pos_boundary_over");
        check(-12'sd128,  -8'sd128, 1'b0, "neg_boundary_exact");
        check(-12'sd129,  -8'sd128, 1'b1, "neg_boundary_under");
        check(12'sd2000,  8'sd127,  1'b1, "large_pos_overflow");
        check(-12'sd2000, -8'sd128, 1'b1, "large_neg_overflow");
        check(12'sd0,     8'sd0,    1'b0, "zero");

        $display("---- tb_saturate done: %0d/%0d passed ----", tests-errors, tests);
        if (errors == 0) $display("*** ALL TESTS PASSED ***");
        else $display("*** %0d TEST(S) FAILED ***", errors);
        $finish;
    end

endmodule