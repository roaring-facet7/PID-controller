// derivative.v
// D term of PID: d_out = Kd * (error_in - error_prev), registered on sample_en.
// Raw derivative (no filtering) -- amplifies high-frequency noise, so if the
// demodulated input turns out noisy in sim/hardware, revisit with a 1-pole
// low-pass on the delta before multiplying by Kd.
// Kd is fixed-point, same Q-format convention as Kp/Ki (default Q4.12).

`timescale 1ns/1ps

module derivative #(
    parameter DATA_WIDTH  = 16,
    parameter COEFF_WIDTH = 16,
    parameter FRAC_BITS   = 12,
    parameter OUT_WIDTH   = 32
) (
    input  wire                          clk,
    input  wire                          rst_n,
    input  wire                          sample_en,
    input  wire signed [DATA_WIDTH-1:0]  error_in,
    input  wire signed [COEFF_WIDTH-1:0] kd,
    output reg  signed [OUT_WIDTH-1:0]   d_out
);

    reg signed [DATA_WIDTH-1:0] error_prev;

    wire signed [DATA_WIDTH:0] error_delta;
    assign error_delta = error_in - error_prev;

    wire signed [DATA_WIDTH+COEFF_WIDTH:0] product;
    assign product = error_delta * kd;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            d_out      <= {OUT_WIDTH{1'b0}};
            error_prev <= {DATA_WIDTH{1'b0}};
        end else if (sample_en) begin
            d_out      <= product >>> FRAC_BITS;
            error_prev <= error_in;
        end
    end

endmodule